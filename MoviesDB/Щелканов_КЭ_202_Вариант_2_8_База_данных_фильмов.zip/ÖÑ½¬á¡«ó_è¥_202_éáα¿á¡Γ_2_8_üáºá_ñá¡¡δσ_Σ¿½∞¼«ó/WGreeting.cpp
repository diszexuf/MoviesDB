#include "WGreeting.h"

using namespace MoviesDB;
using namespace System;

int greet(array<String^>^ args) {
	Application::SetCompatibleTextRenderingDefault(false);
	Application::EnableVisualStyles();
	return 0;
}
