#include "WEditMenu.h"

using namespace MoviesDB;
using namespace System;

int edit(array<String^>^ args) {
	Application::SetCompatibleTextRenderingDefault(false);
	Application::EnableVisualStyles();
	return 0;
}